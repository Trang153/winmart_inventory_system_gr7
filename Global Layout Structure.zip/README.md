
  # Global Layout Structure

  This is a code bundle for Global Layout Structure. The original project is available at https://www.figma.com/design/YWeI5M3rEGupk5UTYT3XKk/Global-Layout-Structure.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  