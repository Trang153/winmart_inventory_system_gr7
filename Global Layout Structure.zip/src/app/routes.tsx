import { createBrowserRouter } from "react-router";
import { DashboardLayout } from "./components/dashboard-layout";
import { LoginPage } from "./pages/login-page";
import { DashboardPage } from "./pages/dashboard-page";
import { ReportsPage } from "./pages/reports-page";
import { SuppliersPage } from "./pages/suppliers-page";
import { AddSupplierPage } from "./pages/add-supplier-page";
import { ReturnTrackingPage } from "./pages/return-tracking-page";
import { OrdersPage } from "./pages/orders-page";
import { SellersPage } from "./pages/sellers-page";
import { RatingPage } from "./pages/rating-page";
import { SettingsPage } from "./pages/settings-page";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/",
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardPage },
      { path: "dashboard", Component: DashboardPage },
      { path: "reports", Component: ReportsPage },
      { path: "suppliers", Component: SuppliersPage },
      { path: "suppliers/add", Component: AddSupplierPage },
      { path: "suppliers/returns", Component: ReturnTrackingPage },
      { path: "orders", Component: OrdersPage },
      { path: "sellers", Component: SellersPage },
      { path: "rating", Component: RatingPage },
      { path: "settings", Component: SettingsPage },
    ],
  },
]);