import { Link, useLocation } from "react-router";
import {
  LayoutDashboard,
  FileText,
  Users,
  ShoppingCart,
  Store,
  Star,
  Settings,
  LogOut,
} from "lucide-react";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: FileText, label: "Reports", path: "/reports" },
  { icon: Users, label: "Suppliers", path: "/suppliers" },
  { icon: ShoppingCart, label: "Orders", path: "/orders" },
  { icon: Store, label: "Sellers", path: "/sellers" },
  { icon: Star, label: "Rating", path: "/rating" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export function Sidebar() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/" || location.pathname === "/dashboard";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="w-64 bg-white h-screen fixed left-0 top-0 border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-[#E52428]">WinMart</h1>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 py-6">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-6 py-3 transition-colors ${
                active
                  ? "bg-red-50 text-[#E52428] border-r-4 border-[#E52428]"
                  : "text-gray-700 hover:bg-gray-50"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Log Out */}
      <div className="p-6 border-t border-gray-200">
        <Link
          to="/login"
          className="flex items-center gap-3 text-gray-700 hover:text-[#E52428] transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Log Out</span>
        </Link>
      </div>
    </div>
  );
}