import { useState } from "react";
import { DashboardCard } from "../components/dashboard-card";
import { Plus, X, Upload } from "lucide-react";

const sellers = [
  {
    storeName: "Tech Store NYC",
    address: "123 Main St, New York, NY 10001",
    contactNumber: "+1 (555) 123-4567",
  },
  {
    storeName: "Fashion Hub LA",
    address: "456 Sunset Blvd, Los Angeles, CA 90028",
    contactNumber: "+1 (555) 234-5678",
  },
  {
    storeName: "Sports Zone Miami",
    address: "789 Ocean Drive, Miami, FL 33139",
    contactNumber: "+1 (555) 345-6789",
  },
  {
    storeName: "Home Goods Chicago",
    address: "321 Michigan Ave, Chicago, IL 60601",
    contactNumber: "+1 (555) 456-7890",
  },
];

export function SellersPage() {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    sellerName: "",
    product: "",
    category: "",
    email: "",
    contactNumber: "",
    warehouseAddress: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowModal(false);
    setFormData({
      sellerName: "",
      product: "",
      category: "",
      email: "",
      contactNumber: "",
      warehouseAddress: "",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Sellers Management</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
        >
          <Plus className="w-4 h-4" />
          Add Seller
        </button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {sellers.map((seller, index) => (
          <DashboardCard key={index}>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">{seller.storeName}</h3>
                <button className="text-[#E52428] hover:underline text-sm">Edit</button>
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium">Address:</span> {seller.address}
                </p>
                <p className="text-gray-600">
                  <span className="font-medium">Contact:</span> {seller.contactNumber}
                </p>
              </div>
            </div>
          </DashboardCard>
        ))}
      </div>

      {/* Add Seller Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Add New Seller</h2>
              <button onClick={() => setShowModal(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Seller Name</label>
                  <input
                    type="text"
                    value={formData.sellerName}
                    onChange={(e) =>
                      setFormData({ ...formData, sellerName: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Product</label>
                  <input
                    type="text"
                    value={formData.product}
                    onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  >
                    <option value="">Select category</option>
                    <option value="electronics">Electronics</option>
                    <option value="clothing">Clothing</option>
                    <option value="food">Food & Beverage</option>
                    <option value="furniture">Furniture</option>
                    <option value="sports">Sports</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Contact Number</label>
                  <input
                    type="tel"
                    value={formData.contactNumber}
                    onChange={(e) =>
                      setFormData({ ...formData, contactNumber: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Warehouse Address</label>
                  <input
                    type="text"
                    value={formData.warehouseAddress}
                    onChange={(e) =>
                      setFormData({ ...formData, warehouseAddress: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>
              </div>

              {/* Upload Avatar */}
              <div>
                <label className="block text-sm font-medium mb-2">Upload Avatar</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600">Upload seller avatar</p>
                  <input type="file" className="hidden" id="seller-avatar" accept="image/*" />
                  <label
                    htmlFor="seller-avatar"
                    className="inline-block mt-2 px-4 py-2 bg-gray-100 text-sm rounded-lg cursor-pointer hover:bg-gray-200"
                  >
                    Choose File
                  </label>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
                >
                  Add Seller
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
