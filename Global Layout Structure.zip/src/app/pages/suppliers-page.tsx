import { DashboardCard } from "../components/dashboard-card";
import { Plus, Filter, Download, Package } from "lucide-react";
import { useNavigate } from "react-router";

const suppliers = [
  {
    name: "ABC Suppliers Inc.",
    product: "Electronics",
    amount: "$45,000",
    orderDate: "2024-03-10",
    status: "Active",
  },
  {
    name: "Global Imports Ltd.",
    product: "Clothing",
    amount: "$32,500",
    orderDate: "2024-03-12",
    status: "Active",
  },
  {
    name: "Tech Distributors",
    product: "Computers",
    amount: "$78,900",
    orderDate: "2024-03-08",
    status: "Pending",
  },
  {
    name: "Food & Beverage Co.",
    product: "Groceries",
    amount: "$23,400",
    orderDate: "2024-03-14",
    status: "Active",
  },
  {
    name: "Home Essentials",
    product: "Furniture",
    amount: "$56,700",
    orderDate: "2024-03-11",
    status: "Active",
  },
  {
    name: "Sports Equipment Inc.",
    product: "Sports Gear",
    amount: "$34,200",
    orderDate: "2024-03-09",
    status: "Inactive",
  },
];

export function SuppliersPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Suppliers List</h1>
        <div className="flex gap-3">
          <button
            onClick={() => navigate("/suppliers/returns")}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Package className="w-4 h-4" />
            Return Tracking
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="w-4 h-4" />
            Download
          </button>
          <button
            onClick={() => navigate("/suppliers/add")}
            className="flex items-center gap-2 px-4 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
          >
            <Plus className="w-4 h-4" />
            New Supplier
          </button>
        </div>
      </div>

      <DashboardCard>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left py-3 px-4">Supplier Name</th>
                <th className="text-left py-3 px-4">Product</th>
                <th className="text-left py-3 px-4">Total Amount</th>
                <th className="text-left py-3 px-4">Order Date</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-left py-3 px-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((supplier, index) => (
                <tr key={index} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{supplier.name}</td>
                  <td className="py-3 px-4">{supplier.product}</td>
                  <td className="py-3 px-4">{supplier.amount}</td>
                  <td className="py-3 px-4">{supplier.orderDate}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        supplier.status === "Active"
                          ? "bg-green-100 text-green-800"
                          : supplier.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {supplier.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button className="text-[#E52428] hover:underline">Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t">
          <p className="text-sm text-gray-600">Showing 1 to 6 of 6 entries</p>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">
              Previous
            </button>
            <button className="px-3 py-1 bg-[#E52428] text-white rounded">1</button>
            <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">
              Next
            </button>
          </div>
        </div>
      </DashboardCard>
    </div>
  );
}