import { DashboardCard } from "../components/dashboard-card";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

const returnData = [
  {
    supplierName: "ABC Suppliers Inc.",
    product: "Laptop Model X",
    contactNumber: "+1 (555) 123-4567",
    email: "contact@abcsuppliers.com",
    returnType: "Taking Return",
    onTheWay: "Yes",
  },
  {
    supplierName: "Global Imports Ltd.",
    product: "T-Shirt Blue",
    contactNumber: "+1 (555) 234-5678",
    email: "info@globalimports.com",
    returnType: "Not Taking Return",
    onTheWay: "No",
  },
  {
    supplierName: "Tech Distributors",
    product: "Monitor 27inch",
    contactNumber: "+1 (555) 345-6789",
    email: "support@techdist.com",
    returnType: "Taking Return",
    onTheWay: "Yes",
  },
  {
    supplierName: "Food & Beverage Co.",
    product: "Organic Coffee",
    contactNumber: "+1 (555) 456-7890",
    email: "orders@foodbev.com",
    returnType: "Taking Return",
    onTheWay: "No",
  },
  {
    supplierName: "Home Essentials",
    product: "Office Chair",
    contactNumber: "+1 (555) 567-8901",
    email: "hello@homeessentials.com",
    returnType: "Not Taking Return",
    onTheWay: "No",
  },
];

export function ReturnTrackingPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("/suppliers")}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold">Return Tracking</h1>
      </div>

      <DashboardCard>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left py-3 px-4">Supplier Name</th>
                <th className="text-left py-3 px-4">Product</th>
                <th className="text-left py-3 px-4">Contact Number</th>
                <th className="text-left py-3 px-4">Email</th>
                <th className="text-left py-3 px-4">Return Type</th>
                <th className="text-left py-3 px-4">On the way</th>
              </tr>
            </thead>
            <tbody>
              {returnData.map((item, index) => (
                <tr key={index} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{item.supplierName}</td>
                  <td className="py-3 px-4">{item.product}</td>
                  <td className="py-3 px-4">{item.contactNumber}</td>
                  <td className="py-3 px-4 text-blue-600">{item.email}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        item.returnType === "Taking Return"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {item.returnType}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        item.onTheWay === "Yes"
                          ? "bg-blue-100 text-blue-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {item.onTheWay}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DashboardCard>
    </div>
  );
}