import { DashboardCard } from "../components/dashboard-card";
import { Star, Trash2, Filter, Search } from "lucide-react";

const ratingStats = [
  { label: "Total Rating", value: "4,567" },
  { label: "Average Rating", value: "4.2" },
  { label: "Total Good Reviews", value: "3,890" },
  { label: "Total Complaints", value: "234" },
];

const ratings = [
  {
    supplier: "ABC Suppliers Inc.",
    stars: 5,
    rating: "5.0",
    feedback: "Excellent service and quality products!",
    date: "2024-03-10",
    status: "Published",
  },
  {
    supplier: "Global Imports Ltd.",
    stars: 4,
    rating: "4.0",
    feedback: "Good products but delivery was slow.",
    date: "2024-03-12",
    status: "Published",
  },
  {
    supplier: "Tech Distributors",
    stars: 5,
    rating: "5.0",
    feedback: "Outstanding quality and fast shipping!",
    date: "2024-03-08",
    status: "Published",
  },
  {
    supplier: "Food & Beverage Co.",
    stars: 3,
    rating: "3.0",
    feedback: "Average quality, could be better.",
    date: "2024-03-14",
    status: "Under Review",
  },
  {
    supplier: "Home Essentials",
    stars: 4,
    rating: "4.5",
    feedback: "Great furniture, very satisfied!",
    date: "2024-03-11",
    status: "Published",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`w-4 h-4 ${
            star <= count ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
          }`}
        />
      ))}
    </div>
  );
}

export function RatingPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Rating</h1>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Search className="w-4 h-4" />
            Search
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]">
            <Trash2 className="w-4 h-4" />
            Delete Rating
          </button>
        </div>
      </div>

      {/* Rating Stats */}
      <div className="grid grid-cols-4 gap-6">
        {ratingStats.map((stat) => (
          <DashboardCard key={stat.label}>
            <div>
              <p className="text-sm text-gray-600">{stat.label}</p>
              <p className="text-2xl font-bold mt-1">{stat.value}</p>
            </div>
          </DashboardCard>
        ))}
      </div>

      {/* Ratings Table */}
      <DashboardCard>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left py-3 px-4">Supplier</th>
                <th className="text-left py-3 px-4">Star Rating</th>
                <th className="text-left py-3 px-4">Numeric Rating</th>
                <th className="text-left py-3 px-4">Feedback</th>
                <th className="text-left py-3 px-4">Date</th>
                <th className="text-left py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {ratings.map((rating, index) => (
                <tr key={index} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{rating.supplier}</td>
                  <td className="py-3 px-4">
                    <StarRating count={rating.stars} />
                  </td>
                  <td className="py-3 px-4">{rating.rating}</td>
                  <td className="py-3 px-4 max-w-xs truncate">{rating.feedback}</td>
                  <td className="py-3 px-4">{rating.date}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        rating.status === "Published"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {rating.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DashboardCard>
    </div>
  );
}
