import { DashboardCard } from "../components/dashboard-card";
import { Users, DollarSign, TrendingUp, TrendingDown } from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const statsData = [
  { label: "Sellers", value: "1,234", icon: Users, color: "bg-blue-500" },
  { label: "Revenue", value: "$89,234", icon: DollarSign, color: "bg-green-500" },
  { label: "Profit", value: "$34,567", icon: TrendingUp, color: "bg-purple-500" },
  { label: "Cost", value: "$54,667", icon: TrendingDown, color: "bg-orange-500" },
];

const salesPurchaseData = [
  { month: "Jan", sales: 4000, purchase: 2400 },
  { month: "Feb", sales: 3000, purchase: 1398 },
  { month: "Mar", sales: 2000, purchase: 9800 },
  { month: "Apr", sales: 2780, purchase: 3908 },
  { month: "May", sales: 1890, purchase: 4800 },
  { month: "Jun", sales: 2390, purchase: 3800 },
];

const inventoryData = [
  { month: "Jan", inbound: 120, outbound: 80 },
  { month: "Feb", inbound: 150, outbound: 100 },
  { month: "Mar", inbound: 180, outbound: 120 },
  { month: "Apr", inbound: 200, outbound: 150 },
  { month: "May", inbound: 170, outbound: 130 },
  { month: "Jun", inbound: 190, outbound: 140 },
];

const topSellers = [
  { name: "Product A", sales: "$12,345", orders: 234 },
  { name: "Product B", sales: "$10,234", orders: 198 },
  { name: "Product C", sales: "$9,456", orders: 176 },
  { name: "Product D", sales: "$8,234", orders: 154 },
];

const lowStockItems = [
  { name: "Product X", quantity: 12, reorderLevel: 50 },
  { name: "Product Y", quantity: 8, reorderLevel: 30 },
  { name: "Product Z", quantity: 5, reorderLevel: 25 },
];

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard Overview</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6">
        {statsData.map((stat) => {
          const Icon = stat.icon;
          return (
            <DashboardCard key={stat.label}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </DashboardCard>
          );
        })}
      </div>

      {/* Second Row - Summary Cards */}
      <div className="grid grid-cols-3 gap-6">
        <DashboardCard title="Inventory Summary">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Products:</span>
              <span className="font-semibold">1,234</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">In Stock:</span>
              <span className="font-semibold">987</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Low Stock:</span>
              <span className="font-semibold text-orange-500">23</span>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Purchase Overview">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Orders:</span>
              <span className="font-semibold">456</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Pending:</span>
              <span className="font-semibold text-yellow-500">34</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Completed:</span>
              <span className="font-semibold text-green-500">422</span>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Product Summary">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Categories:</span>
              <span className="font-semibold">45</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Suppliers:</span>
              <span className="font-semibold">234</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Returns:</span>
              <span className="font-semibold text-red-500">12</span>
            </div>
          </div>
        </DashboardCard>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-6">
        <DashboardCard title="Sales & Purchase">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={salesPurchaseData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="sales" fill="#E52428" />
              <Bar dataKey="purchase" fill="#6366f1" />
            </BarChart>
          </ResponsiveContainer>
        </DashboardCard>

        <DashboardCard title="Inbound vs Outbound Inventory">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={inventoryData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="inbound" stroke="#10b981" strokeWidth={2} />
              <Line type="monotone" dataKey="outbound" stroke="#f59e0b" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </DashboardCard>
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-2 gap-6">
        <DashboardCard title="Top Sellers">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Product</th>
                  <th className="text-left py-2">Sales</th>
                  <th className="text-left py-2">Orders</th>
                </tr>
              </thead>
              <tbody>
                {topSellers.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-2">{item.name}</td>
                    <td className="py-2">{item.sales}</td>
                    <td className="py-2">{item.orders}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </DashboardCard>

        <DashboardCard title="Low Quantity Stock">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Product</th>
                  <th className="text-left py-2">Quantity</th>
                  <th className="text-left py-2">Reorder Level</th>
                </tr>
              </thead>
              <tbody>
                {lowStockItems.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-2">{item.name}</td>
                    <td className="py-2 text-red-500">{item.quantity}</td>
                    <td className="py-2">{item.reorderLevel}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </DashboardCard>
      </div>
    </div>
  );
}
