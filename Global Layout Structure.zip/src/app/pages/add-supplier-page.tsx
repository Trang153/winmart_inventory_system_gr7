import { useState } from "react";
import { DashboardCard } from "../components/dashboard-card";
import { Upload, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

export function AddSupplierPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    supplierName: "",
    product: "",
    category: "",
    buyingPrice: "",
    contactNumber: "",
    type: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission - redirect back to suppliers list
    navigate("/suppliers");
  };

  const handleDiscard = () => {
    navigate("/suppliers");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("/suppliers")}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold">Add New Supplier</h1>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left side - takes 2 columns */}
        <div className="col-span-2">
          <DashboardCard>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Supplier Name</label>
                  <input
                    type="text"
                    value={formData.supplierName}
                    onChange={(e) =>
                      setFormData({ ...formData, supplierName: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="Enter supplier name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Product</label>
                  <input
                    type="text"
                    value={formData.product}
                    onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="Enter product"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  >
                    <option value="">Select category</option>
                    <option value="electronics">Electronics</option>
                    <option value="clothing">Clothing</option>
                    <option value="food">Food & Beverage</option>
                    <option value="furniture">Furniture</option>
                    <option value="sports">Sports</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Buying Price</label>
                  <input
                    type="text"
                    value={formData.buyingPrice}
                    onChange={(e) =>
                      setFormData({ ...formData, buyingPrice: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="$0.00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Contact Number</label>
                  <input
                    type="tel"
                    value={formData.contactNumber}
                    onChange={(e) =>
                      setFormData({ ...formData, contactNumber: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="+1 (555) 000-0000"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  >
                    <option value="">Select type</option>
                    <option value="distributor">Distributor</option>
                    <option value="manufacturer">Manufacturer</option>
                    <option value="wholesaler">Wholesaler</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={handleDiscard}
                  className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
                >
                  Add Supplier
                </button>
              </div>
            </form>
          </DashboardCard>
        </div>

        {/* Right side - Upload Image */}
        <div>
          <DashboardCard title="Supplier Image">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 mx-auto text-gray-400 mb-2" />
              <p className="text-sm text-gray-600 mb-2">Upload supplier avatar</p>
              <p className="text-xs text-gray-400">PNG, JPG up to 5MB</p>
              <input type="file" className="hidden" id="file-upload" accept="image/*" />
              <label
                htmlFor="file-upload"
                className="inline-block mt-4 px-4 py-2 bg-gray-100 text-sm rounded-lg cursor-pointer hover:bg-gray-200"
              >
                Choose File
              </label>
            </div>
          </DashboardCard>
        </div>
      </div>
    </div>
  );
}