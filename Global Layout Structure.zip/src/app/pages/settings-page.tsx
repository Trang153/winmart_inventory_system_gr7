import { DashboardCard } from "../components/dashboard-card";
import { Switch } from "../components/ui/switch";

export function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">System Settings</h1>

      <DashboardCard title="General Settings">
        <div className="grid grid-cols-3 gap-6">
          {/* Column 1 */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">System Language</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>English (US)</option>
                <option>Spanish</option>
                <option>French</option>
                <option>German</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Admin Dashboard Theme</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>Light</option>
                <option>Dark</option>
                <option>Auto</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Time Zone</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>UTC-5 (Eastern Time)</option>
                <option>UTC-6 (Central Time)</option>
                <option>UTC-7 (Mountain Time)</option>
                <option>UTC-8 (Pacific Time)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Currency</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>USD ($)</option>
                <option>EUR (€)</option>
                <option>GBP (£)</option>
                <option>JPY (¥)</option>
              </select>
            </div>
          </div>

          {/* Column 2 */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">System Font</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>System Default</option>
                <option>Arial</option>
                <option>Helvetica</option>
                <option>Roboto</option>
              </select>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">User Sign Up</label>
              <Switch />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Default Theme for Users</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>Light</option>
                <option>Dark</option>
                <option>Auto</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Date & Time Format</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>MM/DD/YYYY</option>
                <option>DD/MM/YYYY</option>
                <option>YYYY-MM-DD</option>
              </select>
            </div>
          </div>

          {/* Column 3 */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Notifications</label>
              <Switch defaultChecked />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">System Update Frequency</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>Daily</option>
                <option>Weekly</option>
                <option>Monthly</option>
                <option>Manual</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Security Checks Frequency</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>Daily</option>
                <option>Weekly</option>
                <option>Monthly</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Log/Reports File Format</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]">
                <option>PDF</option>
                <option>CSV</option>
                <option>Excel</option>
                <option>JSON</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-6 mt-6 border-t">
          <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Reset to Default
          </button>
          <button className="px-6 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]">
            Save Changes
          </button>
        </div>
      </DashboardCard>
    </div>
  );
}
