import { useState } from "react";
import { DashboardCard } from "../components/dashboard-card";
import { Plus, X } from "lucide-react";
import { Checkbox } from "../components/ui/checkbox";

const orderStats = [
  { label: "Total Orders", value: "1,456", color: "bg-blue-500" },
  { label: "Total Received", value: "1,234", color: "bg-green-500" },
  { label: "Total Returned", value: "45", color: "bg-red-500" },
  { label: "On the way", value: "177", color: "bg-yellow-500" },
];

const orders = [
  {
    product: "Laptop Model X",
    orderValue: "$1,299",
    quantity: 15,
    orderId: "ORD-001",
    expectedDelivery: "2024-03-20",
    status: "Confirmed",
  },
  {
    product: "Office Chair",
    orderValue: "$450",
    quantity: 30,
    orderId: "ORD-002",
    expectedDelivery: "2024-03-18",
    status: "Out for delivery",
  },
  {
    product: "Monitor 27inch",
    orderValue: "$350",
    quantity: 20,
    orderId: "ORD-003",
    expectedDelivery: "2024-03-25",
    status: "Delayed",
  },
  {
    product: "Keyboard Wireless",
    orderValue: "$80",
    quantity: 50,
    orderId: "ORD-004",
    expectedDelivery: "2024-03-15",
    status: "Returned",
  },
  {
    product: "Mouse Bluetooth",
    orderValue: "$45",
    quantity: 60,
    orderId: "ORD-005",
    expectedDelivery: "2024-03-22",
    status: "Confirmed",
  },
];

export function OrdersPage() {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    productName: "",
    productId: "",
    category: "",
    orderValue: "",
    quantity: "",
    unit: "",
    buyingPrice: "",
    deliveryDate: "",
    notifyOnDelivery: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowModal(false);
    setFormData({
      productName: "",
      productId: "",
      category: "",
      orderValue: "",
      quantity: "",
      unit: "",
      buyingPrice: "",
      deliveryDate: "",
      notifyOnDelivery: false,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Confirmed":
        return "bg-blue-100 text-blue-800";
      case "Out for delivery":
        return "bg-green-100 text-green-800";
      case "Delayed":
        return "bg-orange-100 text-orange-800";
      case "Returned":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Orders</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
        >
          <Plus className="w-4 h-4" />
          New Order
        </button>
      </div>

      {/* Order Stats */}
      <div className="grid grid-cols-4 gap-6">
        {orderStats.map((stat) => (
          <DashboardCard key={stat.label}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold mt-1">{stat.value}</p>
              </div>
              <div className={`${stat.color} w-12 h-12 rounded-full`}></div>
            </div>
          </DashboardCard>
        ))}
      </div>

      {/* Orders Table */}
      <DashboardCard>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left py-3 px-4">Product</th>
                <th className="text-left py-3 px-4">Order Value</th>
                <th className="text-left py-3 px-4">Quantity</th>
                <th className="text-left py-3 px-4">Order ID</th>
                <th className="text-left py-3 px-4">Expected Delivery</th>
                <th className="text-left py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, index) => (
                <tr key={index} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{order.product}</td>
                  <td className="py-3 px-4">{order.orderValue}</td>
                  <td className="py-3 px-4">{order.quantity}</td>
                  <td className="py-3 px-4 text-gray-600">{order.orderId}</td>
                  <td className="py-3 px-4">{order.expectedDelivery}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DashboardCard>

      {/* New Order Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">New Order</h2>
              <button onClick={() => setShowModal(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Product Name</label>
                  <input
                    type="text"
                    value={formData.productName}
                    onChange={(e) =>
                      setFormData({ ...formData, productName: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Product ID</label>
                  <input
                    type="text"
                    value={formData.productId}
                    onChange={(e) => setFormData({ ...formData, productId: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  >
                    <option value="">Select category</option>
                    <option value="electronics">Electronics</option>
                    <option value="furniture">Furniture</option>
                    <option value="office">Office Supplies</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Order Value</label>
                  <input
                    type="text"
                    value={formData.orderValue}
                    onChange={(e) => setFormData({ ...formData, orderValue: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="$0.00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Quantity</label>
                  <input
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Unit</label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="pcs, kg, etc"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Buying Price</label>
                  <input
                    type="text"
                    value={formData.buyingPrice}
                    onChange={(e) =>
                      setFormData({ ...formData, buyingPrice: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    placeholder="$0.00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Date of Delivery</label>
                  <input
                    type="date"
                    value={formData.deliveryDate}
                    onChange={(e) =>
                      setFormData({ ...formData, deliveryDate: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E52428]"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="notify"
                  checked={formData.notifyOnDelivery}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, notifyOnDelivery: checked as boolean })
                  }
                />
                <label htmlFor="notify" className="text-sm">
                  Notify on delivery date
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#E52428] text-white rounded-lg hover:bg-[#c41f23]"
                >
                  Add Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
