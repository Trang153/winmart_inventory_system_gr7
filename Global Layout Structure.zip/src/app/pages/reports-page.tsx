import { useState } from "react";
import { DashboardCard } from "../components/dashboard-card";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, TrendingDown } from "lucide-react";

const monthlySalesData = [
  { month: "Jan", sales: 4000 },
  { month: "Feb", sales: 3000 },
  { month: "Mar", sales: 5000 },
  { month: "Apr", sales: 4500 },
  { month: "May", sales: 6000 },
  { month: "Jun", sales: 5500 },
];

const inventoryTurnoverData = [
  { month: "Jan", turnover: 2.5 },
  { month: "Feb", turnover: 3.0 },
  { month: "Mar", turnover: 2.8 },
  { month: "Apr", turnover: 3.2 },
  { month: "May", turnover: 3.5 },
  { month: "Jun", turnover: 3.8 },
];

const saleRateData = [
  { month: "Jan", rate: 65 },
  { month: "Feb", rate: 72 },
  { month: "Mar", rate: 68 },
  { month: "Apr", rate: 75 },
  { month: "May", rate: 80 },
  { month: "Jun", rate: 85 },
];

const bestSellingProducts = [
  { product: "Product A", id: "P001", category: "Electronics", quantity: 450, turnover: 3.5, increase: 12.5 },
  { product: "Product B", id: "P002", category: "Clothing", quantity: 380, turnover: 4.2, increase: 8.3 },
  { product: "Product C", id: "P003", category: "Home & Garden", quantity: 320, turnover: 2.8, increase: 15.7 },
  { product: "Product D", id: "P004", category: "Sports", quantity: 290, turnover: 3.1, increase: 6.2 },
  { product: "Product E", id: "P005", category: "Electronics", quantity: 275, turnover: 3.8, increase: 10.4 },
];

const demandForecastData = [
  { month: "Jul", forecast: 5800 },
  { month: "Aug", forecast: 6200 },
  { month: "Sep", forecast: 6500 },
  { month: "Oct", forecast: 7000 },
  { month: "Nov", forecast: 7500 },
  { month: "Dec", forecast: 8200 },
];

export function ReportsPage() {
  const [activeTab, setActiveTab] = useState("inventory");

  const tabs = [
    { id: "inventory", label: "Inventory" },
    { id: "history", label: "History" },
    { id: "turnover", label: "Turnover Analysis" },
    { id: "tracking", label: "Tracking Vendor" },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Reports</h1>

      {/* Tabs */}
      <div className="flex gap-4 border-b">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`pb-2 px-4 transition-colors ${
              activeTab === tab.id
                ? "border-b-2 border-[#E52428] text-[#E52428]"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-3 gap-6">
        <DashboardCard title="Monthly Sales">
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthlySalesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" fill="#E52428" />
            </BarChart>
          </ResponsiveContainer>
        </DashboardCard>

        <DashboardCard title="Inventory Turnover">
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={inventoryTurnoverData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="turnover" stroke="#10b981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </DashboardCard>

        <DashboardCard title="Sale Rate">
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={saleRateData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="rate" stroke="#6366f1" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </DashboardCard>
      </div>

      {/* Best Selling Products Table */}
      <DashboardCard title="Best Selling Products">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left py-3 px-4">Product</th>
                <th className="text-left py-3 px-4">Product ID</th>
                <th className="text-left py-3 px-4">Category</th>
                <th className="text-left py-3 px-4">Remaining Quantity</th>
                <th className="text-left py-3 px-4">Turnover</th>
                <th className="text-left py-3 px-4">Increase %</th>
              </tr>
            </thead>
            <tbody>
              {bestSellingProducts.map((item, index) => (
                <tr key={index} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{item.product}</td>
                  <td className="py-3 px-4 text-gray-600">{item.id}</td>
                  <td className="py-3 px-4">{item.category}</td>
                  <td className="py-3 px-4">{item.quantity}</td>
                  <td className="py-3 px-4">{item.turnover}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1 text-green-600">
                      <TrendingUp className="w-4 h-4" />
                      {item.increase}%
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DashboardCard>

      {/* Demand Forecast */}
      <DashboardCard title="Demand Forecast">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={demandForecastData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="forecast"
              stroke="#f59e0b"
              strokeWidth={2}
              strokeDasharray="5 5"
            />
          </LineChart>
        </ResponsiveContainer>
      </DashboardCard>
    </div>
  );
}
